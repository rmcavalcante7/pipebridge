# ============================================================
# Dependencies
# ============================================================
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from pipefy.client.httpClient import PipefyHttpClient
from pipefy.service.cardService import CardService
from pipefy.exceptions import (
    RequestError,
    ValidationError,
    UnexpectedResponseError,
    getExceptionContext
)


class FileService:
    """
    Service responsible for file upload operations in Pipefy.

    This service handles file-related workflows including:
    - Generating presigned upload URLs
    - Uploading binary content to Pipefy storage
    - Linking uploaded files to cards via fields

    It orchestrates:
    - HTTP client (GraphQL communication)
    - CardService (field updates)

    :example:
        >>> client = PipefyHttpClient(auth_key="token", base_url="https://api.pipefy.com/graphql")
        >>> card_service = CardService(client)
        >>> service = FileService(client, card_service)
        >>> isinstance(service, FileService)
        True
    """

    def __init__(
        self,
        client: PipefyHttpClient,
        card_service: CardService
    ) -> None:
        """
        Initialize FileService.

        :param client: PipefyHttpClient = HTTP client instance
        :param card_service: CardService = Card service instance

        :example:
            >>> client = PipefyHttpClient(auth_key="token", base_url="https://api.pipefy.com/graphql")
            >>> card_service = CardService(client)
            >>> service = FileService(client, card_service)
        """
        self._client: PipefyHttpClient = client
        self._card_service: CardService = card_service

    # ============================================================
    # File Upload
    # ============================================================

    def uploadFile(
        self,
        file_name: str,
        file_bytes: bytes,
        card_id: str,
        field_id: str,
        organization_id: int
    ) -> bool:
        """
        Upload a file and attach it to a card field.

        This method performs a multistep workflow:
        1. Requests a presigned upload URL from Pipefy
        2. Uploads the file using HTTP PUT
        3. Extracts the stored file path
        4. Updates the card field with the uploaded file reference

        :param file_name: str = Name of the file (including extension)
        :param file_bytes: bytes = Binary content of the file
        :param card_id: str = Target card ID
        :param field_id: str = Field ID to attach the file
        :param organization_id: int = Pipefy organization ID

        :return: bool = True if upload and attachment succeed

        :raises ValidationError:
            When input parameters are invalid
        :raises UnexpectedResponseError:
            When API response structure is invalid
        :raises RequestError:
            When upload or request execution fails

        :example:
            >>> client = PipefyHttpClient(auth_key="token", base_url="https://api.pipefy.com/graphql")
            >>> card_service = CardService(client)
            >>> service = FileService(client, card_service)
            >>> fake_bytes = b"hello world"
            >>> callable(service.uploadFile)
            True
        """
        class_name, method_name = getExceptionContext(self)

        # ====================================================
        # Validation
        # ====================================================
        if not file_name or not isinstance(file_name, str):
            raise ValidationError(
                message="file_name must be a non-empty string",
                class_name=class_name,
                method_name=method_name
            )

        if not file_bytes or not isinstance(file_bytes, bytes):
            raise ValidationError(
                message="file_bytes must be bytes",
                class_name=class_name,
                method_name=method_name
            )

        if not card_id or not isinstance(card_id, str):
            raise ValidationError(
                message="card_id must be a non-empty string",
                class_name=class_name,
                method_name=method_name
            )

        if not field_id or not isinstance(field_id, str):
            raise ValidationError(
                message="field_id must be a non-empty string",
                class_name=class_name,
                method_name=method_name
            )

        if not isinstance(organization_id, str):
            raise ValidationError(
                message="organization_id must be an integer",
                class_name=class_name,
                method_name=method_name
            )

        try:
            # Step 1
            query = f"""
                    mutation {{
                        createPresignedUrl(input: {{
                            fileName: "{file_name}",
                            organizationId: {organization_id}
                        }}) {{
                            url
                            downloadUrl
                        }}
                    }}
                    """

            graphql_response: Dict[str, Any] = self._client.sendRequest(query)

            try:
                presigned = graphql_response["data"]["createPresignedUrl"]
                url_put: str = presigned["url"]
                download_url: str = presigned["downloadUrl"]
            except Exception as exc:
                raise UnexpectedResponseError(
                    message="Invalid presigned URL response structure",
                    class_name=class_name,
                    method_name=method_name
                ) from exc

            # Step 2
            headers = {
                "Content-Type": f"application/{file_name.split('.')[-1]}"
            }

            upload_response = requests.put(
                url_put,
                data=file_bytes,
                headers=headers,
                timeout=60
            )

            if upload_response.status_code not in (200, 201):
                raise RequestError(
                    message=f"Upload failed with status {upload_response.status_code}",
                    class_name=class_name,
                    method_name=method_name
                )

            # Step 3
            match = re.findall(r'(orgs.+)\?', download_url)

            if not match:
                raise UnexpectedResponseError(
                    message="Could not extract file path from download URL",
                    class_name=class_name,
                    method_name=method_name
                )

            file_path: str = match[0]

            # Step 4
            result: Dict[str, Any] = self._card_service.updateFields(
                card_id,
                {
                    field_id: [
                        {
                            "path": file_path
                        }
                    ]
                }
            )

            try:
                return result["data"]["updateFieldsValues"]["success"]
            except Exception as exc:
                raise UnexpectedResponseError(
                    message="Invalid response when attaching file",
                    class_name=class_name,
                    method_name=method_name
                ) from exc

        except (ValidationError, UnexpectedResponseError):
            raise

        except Exception as exc:
            raise RequestError(
                message=str(exc),
                class_name=class_name,
                method_name=method_name
            ) from exc

    # ============================================================
    # File Download
    # ============================================================
    def downloadAllAttachments(
            self,
            card_id: str,
            output_dir: str
    ) -> List[Path]:
        """
        Download all attachments from a card.

        This method:
        - Retrieves card attachments via CardService
        - Downloads each file using its URL
        - Saves files locally into the specified directory

        :param card_id: str = Card ID
        :param output_dir: str = Directory path to save files

        :return: list[Path] = List of saved file paths

        :raises ValidationError:
            When input parameters are invalid
        :raises UnexpectedResponseError:
            When response structure is invalid
        :raises RequestError:
            When download or request execution fails

        :example:
            >>> client = PipefyHttpClient(auth_key="token", base_url="https://api.pipefy.com/graphql")
            >>> card_service = CardService(client)
            >>> service = FileService(client, card_service)
            >>> callable(service.downloadAllAttachments)
            True
        """
        class_name, method_name = getExceptionContext(self)

        if not card_id or not isinstance(card_id, str):
            raise ValidationError(
                message="card_id must be a non-empty string",
                class_name=class_name,
                method_name=method_name
            )

        if not output_dir or not isinstance(output_dir, str):
            raise ValidationError(
                message="output_dir must be a valid string",
                class_name=class_name,
                method_name=method_name
            )

        try:
            response: Dict[str, Any] = self._card_service.getCardStructured(
                card_id,
                query_body="""
                    attachments {
                        url
                    }
                """
            )

            attachments: List[Dict[str, Any]] = response.get("attachments", [])

            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)

            downloaded_files: List[Path] = []

            for attachment in attachments:
                file_url: Optional[str] = attachment.get("url")

                if not file_url:
                    continue

                file_name: str = file_url.split("/")[-1].split("?")[0]
                file_path: Path = output_path / file_name

                download_response: requests.Response = requests.get(
                    file_url,
                    timeout=60
                )

                if download_response.status_code != 200:
                    raise RequestError(
                        message=f"Download failed ({download_response.status_code})",
                        class_name=class_name,
                        method_name=method_name
                    )

                file_path.write_bytes(download_response.content)
                downloaded_files.append(file_path)

            return downloaded_files

        except (ValidationError, UnexpectedResponseError):
            raise

        except Exception as exc:
            raise RequestError(
                message=str(exc),
                class_name=class_name,
                method_name=method_name
            ) from exc

# ============================================================
# Main (Usage Example)
# ============================================================

if __name__ == "__main__":
    """
    Simple execution example.
    """

    try:
        TOKEN = ""
        base_url = "https://api.pipefy.com/graphql"
        client = PipefyHttpClient(auth_key=TOKEN, base_url=base_url)
        card_service = CardService(client)
        file_service = FileService(client, card_service)

        result = file_service.downloadAllAttachments(
            card_id="35850877",
            output_dir="./tmp"
        )

        print("Upload success:", result)

    except Exception as error:
        print("Error occurred:")
        print(error)