# ============================================================
# Dependencies
# ============================================================
from typing import Optional


class FileUploadResult:
    """
    Represents the result of a file upload operation.

    This object encapsulates all relevant information returned after
    uploading a file to Pipefy and attaching it to a card field.

    :param file_path: str = Internal file path used by Pipefy
    :param download_url: str = Public URL to download the file
    :param success: bool = Indicates whether the upload succeeded

    :example:
        >>> result = FileUploadResult("path", "http://url", True)
        >>> result.success
        True
    """

    def __init__(
        self,
        file_path: str,
        download_url: Optional[str],
        success: bool
    ) -> None:
        """
        Initialize FileUploadResult.

        :param file_path: str = Internal file path
        :param download_url: str | None = Download URL
        :param success: bool = Success flag
        """
        self.file_path: str = file_path
        self.download_url: Optional[str] = download_url
        self.success: bool = success