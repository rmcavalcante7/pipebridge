from pipefy.exceptions.base import PipefyError


class ValidationError(PipefyError):
    """
    Raised when input validation fails.
    """
    pass