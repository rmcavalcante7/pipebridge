# Base
from pipefy.exceptions.base import PipefyError

# Core
from pipefy.exceptions.validation import ValidationError
from pipefy.exceptions.parsing import ParsingError, UnexpectedResponseError
from pipefy.exceptions.request import RequestError
from pipefy.exceptions.integration import IntegrationError

# Auth
from pipefy.exceptions.authentication import (
    AuthenticationError,
    MissingTokenError,
    InvalidTokenError,
    ExpiredTokenError,
    UnauthorizedError
)

# Config
from pipefy.exceptions.configuration import (
    ConfigurationError,
    PipefyInitializationError,
    MissingBaseUrlError
)

# Utils
from pipefy.exceptions.utils import getExceptionContext

__all__ = [
    "PipefyError",
    "ValidationError",
    "ParsingError",
    "UnexpectedResponseError",
    "RequestError",
    "IntegrationError",
    "AuthenticationError",
    "MissingTokenError",
    "InvalidTokenError",
    "ExpiredTokenError",
    "UnauthorizedError",
    "ConfigurationError",
    "PipefyInitializationError",
    "MissingBaseUrlError",
    "getExceptionContext",
]