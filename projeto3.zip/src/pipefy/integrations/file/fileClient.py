# ============================================================
# Dependencies
# ============================================================
import json
import re
from typing import Dict, Any, Optional
from urllib.parse import urlparse

from pipefy.client.httpClient import PipefyHttpClient
from pipefy.exceptions import RequestError, ValidationError, UnexpectedResponseError
from pipefy.exceptions.utils import getExceptionContext
from pipefy.service.cardService import CardService
from pipefy.integrations.file.fileUploadResult import FileUploadResult
from pipefy.integrations.file.fileIntegration import FileIntegration
from pipefy.models.file.fileUploadRequest import FileUploadRequest


# ============================================================
# Context
# ============================================================
class FileServiceContext:
    """
    Encapsulates all dependencies required by file operations.

    This object centralizes infrastructure dependencies and ensures
    consistent injection across flows and services.

    :param client: PipefyHttpClient = GraphQL HTTP client
    :param card_service: CardService = Card operations service
    :param file_integration: FileIntegration = Storage integration layer

    :raises ValidationError:
        When any dependency is None

    :example:
        >>> callable(FileServiceContext)
        True
    """

    def __init__(
        self,
        client: PipefyHttpClient,
        card_service: CardService,
        file_integration: FileIntegration
    ) -> None:
        class_name, method_name = getExceptionContext(self)

        if client is None:
            raise ValidationError("client must not be None", class_name, method_name)

        if card_service is None:
            raise ValidationError("card_service must not be None", class_name, method_name)

        if file_integration is None:
            raise ValidationError("file_integration must not be None", class_name, method_name)

        self.client = client
        self.card_service = card_service
        self.file_integration = file_integration


# ============================================================
# Upload Flow
# ============================================================
class FileUploadFlow:
    """
    Encapsulates the complete upload use-case.

    This class isolates the upload workflow and prevents FileService
    from becoming overly complex.

    :param context: FileServiceContext

    :example:
        >>> callable(FileUploadFlow)
        True
    """

    def __init__(self, context: FileServiceContext) -> None:
        self._ctx = context

    def execute(self, request: FileUploadRequest) -> FileUploadResult:
        """
        Executes full upload process.

        :param request: FileUploadRequest

        :return: FileUploadResult

        :raises ValidationError:
        :raises RequestError:
        :raises UnexpectedResponseError:

        :example:
            >>> callable(FileUploadFlow.execute)
            True
        """
        class_name, method_name = getExceptionContext(self)

        try:
            presigned = self._createPresignedUrl(
                request.file_name,
                request.organization_id
            )

            data = presigned.get("data", {})
            presigned_data = data.get("createPresignedUrl", {})

            upload_url = presigned_data.get("url")
            download_url = presigned_data.get("downloadUrl")

            if not upload_url:
                raise UnexpectedResponseError(
                    "Invalid upload URL", class_name, method_name
                )

            self._ctx.file_integration.upload(upload_url, request.file_bytes)

            file_path = self._ctx.file_integration.extractFilePath(upload_url)

            files = [file_path]

            if not request.replace_files:
                files += self._getAttachedFiles(request.card_id, request.field_id)

            self._attachToCard(request.card_id, request.field_id, files)

            return FileUploadResult(
                file_path=files,
                download_url=download_url,
                success=True
            )

        except (ValidationError, RequestError, UnexpectedResponseError):
            raise
        except Exception as exc:
            raise RequestError(str(exc), class_name, method_name) from exc

    # ============================================================
    # Internal Steps
    # ============================================================

    def _createPresignedUrl(self, file_name: str, organization_id: str) -> Dict[str, Any]:
        """
        Delegates GraphQL mutation to create presigned URL.

        :param file_name: str
        :param organization_id: str

        :return: dict

        :example:
            >>> callable(FileUploadFlow._createPresignedUrl)
            True
        """
        query = f"""
        mutation {{
            createPresignedUrl(
                input: {{
                    organizationId: {organization_id},
                    fileName: "{file_name}"
                }}
            ) {{
                url
                downloadUrl
            }}
        }}
        """
        return self._ctx.client.sendRequest(query, timeout=60)

    def _getAttachedFiles(self, card_id: str, field_id: str) -> list[str]:
        """
        Retrieves existing attachments and normalizes them.

        :param card_id: str
        :param field_id: str

        :return: list[str]

        :example:
            >>> callable(FileUploadFlow._getAttachedFiles)
            True
        """
        card = self._ctx.card_service.getCardModel(card_id)

        if field_id not in card.fields_map:
            return []

        raw_value = card.fields_map[field_id].value

        if not raw_value:
            return []

        try:
            urls = json.loads(raw_value)
            return [
                self._ctx.file_integration.extractFilePath(url)
                for url in urls
            ]
        except Exception:
            return []

    def _attachToCard(self, card_id: str, field_id: str, files: list[str]) -> None:
        """
        Sends final attachment list to Pipefy.

        :param card_id: str
        :param field_id: str
        :param files: list[str]

        :example:
            >>> callable(FileUploadFlow._attachToCard)
            True
        """
        mutation = f"""
        mutation {{
          updateCardField(input: {{
            card_id: "{card_id}",
            field_id: "{field_id}",
            new_value: {json.dumps(files)}
          }}) {{
            success
          }}
        }}
        """
        self._ctx.client.sendRequest(mutation)


# ============================================================
# FileService
# ============================================================
class FileService:
    """
    Service responsible for file operations.

    This class now acts as a thin entry point and delegates
    upload complexity to FileUploadFlow.

    :param context: FileServiceContext

    :example:
        >>> callable(FileService)
        True
    """

    def __init__(self, context: FileServiceContext) -> None:
        self._ctx = context
        self._upload_flow = FileUploadFlow(context)

    # ============================================================
    # PUBLIC METHODS
    # ============================================================

    def uploadFile(self, request: FileUploadRequest) -> FileUploadResult:
        """
        Uploads file using request object.

        :param request: FileUploadRequest

        :return: FileUploadResult

        :example:
            >>> callable(FileService.uploadFile)
            True
        """
        return self._upload_flow.execute(request)

    def downloadAllAttachments(
        self,
        card_id: str,
        field_id: str,
        timeout: int = 60
    ) -> Dict[str, bytes]:
        """
        Downloads all attachments.

        :param card_id: str
        :param field_id: str
        :param timeout: int

        :return: dict[str, bytes]

        :example:
            >>> callable(FileService.downloadAllAttachments)
            True
        """
        card = self._ctx.card_service.getCardModel(card_id)

        if field_id not in card.fields_map:
            return {}

        raw_value = card.fields_map[field_id].value

        if not raw_value:
            return {}

        attachments = json.loads(raw_value)

        files: Dict[str, bytes] = {}

        for url in attachments:
            name = self.extractFileName(url)
            files[name] = self._ctx.file_integration.download(url, timeout)

        return files

    def extractFileName(self, url: str) -> str:
        """
        Extracts file name from URL.

        :param url: str

        :return: str

        :example:
            >>> callable(FileService.extractFileName)
            True
        """
        return urlparse(url).path.split("/")[-1]