from pipefy.service.file.flows.pipeline.uploadPipelineContext import UploadPipelineContext
from pipefy.exceptions import RequestError
from pipefy.exceptions.utils import getExceptionContext


class UploadStep:
    """
    Upload step with retry support.

    :param retries: int = Number of retry attempts

    :example:
        >>> callable(UploadStep.execute)
        True
    """

    def __init__(self, retries: int = 3) -> None:
        self._retries = retries

    def execute(self, context: UploadPipelineContext) -> None:
        class_name, method_name = getExceptionContext(self)

        last_error = None

        for attempt in range(self._retries):
            try:
                context.integration.upload(
                    context.upload_url,
                    context.request.file_bytes
                )
                return

            except Exception as exc:
                last_error = exc

        raise RequestError(
            f"Upload failed after {self._retries} attempts: {last_error}",
            class_name,
            method_name
        )