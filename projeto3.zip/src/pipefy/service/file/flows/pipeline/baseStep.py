from abc import ABC, abstractmethod
from pipefy.service.file.flows.pipeline.uploadPipelineContext import UploadPipelineContext


class BaseUploadStep(ABC):
    """
    Base class for all upload pipeline steps.

    Each step operates on a strongly-typed UploadPipelineContext.

    :example:
        >>> callable(BaseUploadStep.execute)
        True
    """

    @abstractmethod
    def execute(self, context: UploadPipelineContext) -> None:
        """
        Executes step logic.

        :param context: UploadPipelineContext

        :return: None
        """
        raise NotImplementedError