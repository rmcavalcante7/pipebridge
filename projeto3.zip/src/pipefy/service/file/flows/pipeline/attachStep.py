import json
from pipefy.service.file.flows.pipeline.uploadPipelineContext import UploadPipelineContext


class AttachStep:
    """
    Attaches files to Pipefy card.

    :example:
        >>> callable(AttachStep.execute)
        True
    """

    def execute(self, context: UploadPipelineContext) -> None:
        request = context.request

        mutation = f"""
        mutation {{
          updateCardField(input: {{
            card_id: "{request.card_id}",
            field_id: "{request.field_id}",
            new_value: {json.dumps(context.files)}
          }}) {{
            success
          }}
        }}
        """

        context.client.sendRequest(mutation)