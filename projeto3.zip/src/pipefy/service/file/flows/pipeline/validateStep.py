from pipefy.service.file.flows.pipeline.uploadPipelineContext import UploadPipelineContext
from pipefy.exceptions import ValidationError
from pipefy.exceptions.utils import getExceptionContext


class ValidateStep:
    """
    Validates upload request.

    :example:
        >>> callable(ValidateStep.execute)
        True
    """

    def execute(self, context: UploadPipelineContext) -> None:
        class_name, method_name = getExceptionContext(self)

        if not context.request.file_bytes:
            raise ValidationError(
                "file_bytes cannot be empty",
                class_name,
                method_name
            )