# ============================================================
# Dependencies
# ============================================================
from infra_core import FernetEncryption, CredentialsLoader
from Credentials import MyPipefyCredentials

from pipefy import Pipefy
import traceback
from typing import Dict, Any


# ============================================================
# Setup
# ============================================================

def getApi() -> Pipefy:
    """
    Initialize Pipefy API safely.

    :return: Pipefy = Initialized API client

    :raises Exception:
        When credentials loading fails
    """
    credential = CredentialsLoader.load(
        MyPipefyCredentials,
        FernetEncryption,
        name="pipefy"
    )

    return Pipefy(token=credential.api_token)


# ============================================================
# PIPE TESTS
# ============================================================

def testPipeRaw(api: Pipefy, pipe_id: str) -> None:
    """
    Test raw pipe retrieval.

    :param api: Pipefy
    :param pipe_id: str

    :return: None
    """
    print("\n=== TEST: getPipeRaw ===")

    query_body = """
        id
        name
    """

    result: Dict[str, Any] = api.pipe.getPipeRaw(pipe_id, query_body)

    print("Keys:", result.keys())

    print("✔ getPipeRaw OK")


def testPipeStructured(api: Pipefy, pipe_id: str) -> None:
    """
    Test structured pipe retrieval.

    :param api: Pipefy
    :param pipe_id: str

    :return: None
    """
    print("\n=== TEST: getPipeStructured ===")

    result: Dict[str, Any] = api.getPipeStructured(pipe_id)

    print("ID:", result.get("id"))
    print("Name:", result.get("name"))
    print("Name:", result.get("name"))

    print("Phases:", len(result.get("phases", [])))
    print("Labels:", len(result.get("labels", [])))
    print("Users:", len(result.get("users", [])))

    print("✔ getPipeStructured OK")


def testPipeModel(api: Pipefy, pipe_id: str) -> None:
    """
    Test pipe model parsing and access patterns.

    :param api: Pipefy
    :param pipe_id: str

    :return: None
    """
    print("\n=== TEST: getPipeModel ===")

    pipe = api.getPipeModel(pipe_id)

    print("ID:", pipe.id)
    print("Name:", pipe.name)
    print("Cards:", pipe.cards_count)

    print("Phases count:", len(pipe.phases))
    print("Labels count:", len(pipe.labels))
    print("Users count:", len(pipe.users))

    # ============================================================
    # O(1) ACCESS TESTS
    # ============================================================
    if pipe.phases_map:
        first_phase = next(iter(pipe.phases_map.values()))

        print("First phase:", first_phase.id)

        # getPhase
        phase_by_id = pipe.getPhase(first_phase.id)
        print("Access via getPhase:", phase_by_id.id)

        # __getitem__
        phase_direct = pipe[first_phase.id]
        print("Access via []:", phase_direct.id)

    if pipe.labels_map:
        first_label = next(iter(pipe.labels_map.values()))
        print("First label:", first_label.id)

        label = pipe.getLabel(first_label.id)
        print("Access label:", label.id)

    if pipe.users_map:
        first_user = next(iter(pipe.users_map.values()))

        print("First user:", first_user.id)

        user = pipe.getUser(first_user.id)

        print("Access user:", user.id)
        print("User name:", user.name)
        print("User email:", user.email)

    # ============================================================
    # Parse errors visibility
    # ============================================================
    if hasattr(pipe, "_parse_errors"):
        print("Parse errors:", len(pipe._parse_errors))

    print("✔ getPipeModel OK")


def testPipeCustomQuery(api: Pipefy, pipe_id: str) -> None:
    """
    Test pipe retrieval with custom query.

    :param api: Pipefy
    :param pipe_id: str

    :return: None
    """
    print("\n=== TEST: getPipeModel (custom query) ===")

    query_body = """
        id
        name

        phases {
            id
            name
            fields {
                id
                label
                type
            }
        }
    """

    pipe = api.getPipeModel(pipe_id, query_body=query_body)

    print("ID:", pipe.id)
    print("Name:", pipe.name)

    print("Phases:", len(pipe.phases))

    if pipe.phases:
        first_phase = pipe.phases[0]
        print("First phase:", first_phase.id)

        print("Fields:", len(first_phase.fields))

    print("✔ getPipeModel (custom query) OK")


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    api = getApi()

    PIPE_ID = "11881"

    try:
        # ========================================================
        # CORE FLOW
        # ========================================================
        testPipeRaw(api, PIPE_ID)
        testPipeStructured(api, PIPE_ID)
        testPipeModel(api, PIPE_ID)

        # ========================================================
        # ADVANCED
        # ========================================================
        testPipeCustomQuery(api, PIPE_ID)

        print("\n🎯 ALL TESTS EXECUTED")

    except Exception as error:
        print("\n❌ TEST FAILED:")
        print(error)
        print(traceback.format_exc())