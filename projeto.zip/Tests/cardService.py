# ============================================================
# Dependencies
# ============================================================
from infra_core import FernetEncryption, CredentialsLoader
from Credentials import MyPipefyCredentials

from pipefy import Pipefy

from pprint import pprint

# ============================================================
# Setup
# ============================================================

def getApi() -> Pipefy:
    """
    Initialize Pipefy API safely.

    :return: Pipefy = Initialized API client

    :raises Exception:
        When credential loading fails
    """
    credential = CredentialsLoader.load(
        MyPipefyCredentials,
        FernetEncryption,
        name='pipefy_automation_factory'
    )

    return Pipefy(token=credential.api_token)


# ============================================================
# Tests
# ============================================================

def testRawCard(api: Pipefy, card_id: str) -> None:
    """
    Test raw card query execution.

    :param api: Pipefy
    :param card_id: str

    :return: None
    """
    print("\n=== TEST: getRawCard ===")

    query = """
    fields {
      field {
        id
      }
      value
    }
    """

    result = api.getRawCard(card_id=card_id, query_body=query)

    data = result.get("data", {}).get("card", {})
    fields = data.get("fields", [])
    pprint(data)
    print("Fields:", fields)
    print("✔ getRawCard OK")


def testStructured(api: Pipefy, card_id: str) -> None:
    """
    Test structured card retrieval.

    :param api: Pipefy
    :param card_id: str

    :return: None
    """
    print("\n=== TEST: getCardStructured ===")

    result = api.getCardStructured(card_id)
    pprint(result)
    # print("Keys:", list(result.keys()))
    print("✔ getCardStructured OK")


def testStructuredCustomQuery(api: Pipefy, card_id: str) -> None:
    """
    Test structured card retrieval with custom query.

    :param api: Pipefy
    :param card_id: str

    :return: None
    """
    print("\n=== TEST: getCardStructured (custom query) ===")

    query = """
        fields {
            field {
                id
            }
            value
        }
    """

    result = api.getCardStructured(card_id, query_body=query)
    pprint(result)
    # print("Fields:", result.get("fields", []))
    print("✔ custom query OK")


def testModel(api: Pipefy, card_id: str) -> None:
    """
    Test card model parsing and access patterns.

    :param api: Pipefy
    :param card_id: str

    :return: None
    """
    print("\n=== TEST: getCardModel ===")

    card = api.getCardModel(card_id)

    # ============================================================
    # BASIC
    # ============================================================
    print("ID:", card.id)
    print("Title:", card.title)

    print("Fields count:", len(card.fields))
    print("Assignees:", len(card.assignees))
    print("Labels:", len(card.labels))
    pprint(f"Card:\n{card}", )
    # ============================================================
    # PHASE
    # ============================================================
    if card.current_phase:
        print("Current phase:", card.current_phase.name)

    # ============================================================
    # FIELD ACCESS
    # ============================================================
    print("\n--- FIELD ACCESS ---")

    print("OC:", card.getText("oc"))
    print("Regional:", card.getText("regional"))
    print("Result Code:", card.getNumber("result_code"))

    msg = card.getText("result_message")
    print("Result Message (len):", len(msg) if msg else 0)

    doc_json = card.getText("docd_json")
    print("docd_json exists:", doc_json is not None)

    # ============================================================
    # FIELD MAP (O(1))
    # ============================================================
    print("\n--- FIELD MAP ---")

    field = card.getField("oc")
    if field:
        print("Field 'oc':", field.value)

    print("Available field IDs:", list(card.fields_map.keys())[:5])

    # ============================================================
    # LABEL ACCESS (O(1))
    # ============================================================
    print("\n--- LABEL ACCESS ---")

    if card.labels_map:
        first_label = next(iter(card.labels_map.values()))

        print("First label:", first_label.id)

        label = card.getLabel(first_label.id)
        print("Access label:", label.id)

    print("Available label IDs:", list(card.labels_map.keys()))

    # ============================================================
    # EDGE CASES
    # ============================================================
    print("\n--- EDGE CASES ---")

    print("Non-existing field:", card.getField("nao_existe"))
    print("Non-existing label:", card.getLabel("999999"))

    # ============================================================
    # VALIDATION
    # ============================================================
    print("\n--- VALIDATION ---")

    if card.fields:
        print("First field type:", type(card.fields[0]))

    print("✔ getCardModel OK")


def testListAllCards(api: Pipefy, pipe_id: str) -> None:
    """
    Test listing all cards from pipe.

    :param api: Pipefy
    :param pipe_id: str

    :return: None
    """
    print("\n=== TEST: listAllCards ===")

    cards = api.card.listAllCards(pipe_id=pipe_id)

    print("Total cards:", len(cards))
    print("✔ listAllCards OK")


def testListCardsFromPhase(api: Pipefy, phase_id: str) -> None:
    """
    Test listing cards from a phase.

    :param api: Pipefy
    :param phase_id: str

    :return: None
    """
    print("\n=== TEST: listCardsFromPhase ===")

    cards = api.card.listCardsFromPhase(phase_id=phase_id)

    print("Total cards:", len(cards))
    print("✔ listCardsFromPhase OK")


def testPaginationPhase(api: Pipefy, phase_id: str) -> None:
    """
    Test paginated retrieval of cards from a phase.

    :param api: Pipefy
    :param phase_id: str

    :return: None
    """
    print("\n=== TEST: listCardsFromPhasePaginated ===")

    cards = api.card.listCardsFromPhasePaginated(phase_id=phase_id)

    print("Total cards:", len(cards))

    for card in cards[:5]:
        print(card.id, card.title)

    print("✔ pagination phase OK")


def testPaginationPipe(api: Pipefy, pipe_id: str) -> None:
    """
    Test paginated retrieval of cards from a pipe.

    :param api: Pipefy
    :param pipe_id: str

    :return: None
    """
    print("\n=== TEST: listAllCardsPaginated ===")

    cards = api.card.listAllCardsPaginated(pipe_id=pipe_id)

    print("Total cards:", len(cards))

    for card in cards[:5]:
        print(card.id, card.title)

    print("✔ pagination pipe OK")


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    api = getApi()

    # TIMDECOM
    CARD_ID = "35814650"
    PIPE_ID = "11881"
    PHASE_ID = "83728"

    # Automation Factory
    CARD_ID = "1328390184"
    PIPE_ID = "307064875"
    PHASE_ID = "342616251"
    try:
        testRawCard(api, CARD_ID)
        testStructured(api, CARD_ID)
        testStructuredCustomQuery(api, CARD_ID)
        testModel(api, CARD_ID)

        testListAllCards(api, PIPE_ID)
        testListCardsFromPhase(api, PHASE_ID)

        testPaginationPhase(api, PHASE_ID)
        testPaginationPipe(api, PIPE_ID)

        print("\n🎯 ALL TESTS EXECUTED")

    except Exception as error:
        print("\n❌ TEST FAILED:")
        print(error)