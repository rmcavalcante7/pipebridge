# ============================================================
# Dependencies
# ============================================================
from infra_core import FernetEncryption, CredentialsLoader
from Credentials import MyPipefyCredentials

from pipefy import Pipefy
import traceback
from typing import Dict, Any
from pprint import pprint

# ============================================================
# Setup
# ============================================================

def getApi() -> Pipefy:
    """
    Initialize Pipefy API safely.

    :return: Pipefy = Initialized API client

    :raises Exception:
        When credentials loading fails
    """
    credential = CredentialsLoader.load(
        MyPipefyCredentials,
        FernetEncryption,
        name="pipefy"
    )

    return Pipefy(token=credential.api_token)


# ============================================================
# PHASE TESTS
# ============================================================

def testPhaseRaw(api: Pipefy, phase_id: str) -> None:
    """
    Test raw phase retrieval.

    :param api: Pipefy
    :param phase_id: str

    :return: None
    """
    print("\n=== TEST: getPhaseRaw ===")

    query_body = """
        id
        name
    """

    result: Dict[str, Any] = api.phase.getPhaseRaw(phase_id, query_body)

    print("Keys:")
    pprint(result.keys())
    print("✔ getPhaseRaw OK")


def testPhaseStructured(api: Pipefy, phase_id: str) -> None:
    """
    Test structured phase retrieval.

    :param api: Pipefy
    :param phase_id: str

    :return: None
    """
    print("\n=== TEST: getPhaseStructured ===")

    result: Dict[str, Any] = api.getPhaseStructured(phase_id)

    print("ID:", result.get("id"))
    print("Name:", result.get("name"))

    fields = result.get("fields", [])
    print("Fields count:", len(fields))
    pprint(fields)
    print("✔ getPhaseStructured OK")


def testPhaseModel(api: Pipefy, phase_id: str) -> None:
    """
    Test phase model parsing and access patterns.

    :param api: Pipefy
    :param phase_id: str

    :return: None
    """
    print("\n=== TEST: getPhaseModel ===")

    phase = api.getPhaseModel(phase_id)

    print("ID:", phase.id)
    print("Name:", phase.name)

    print("Fields count:", len(phase.fields))

    # ============================================================
    # Field access patterns (CRITICAL TEST)
    # ============================================================
    if phase.fields_map:
        first_field = next(iter(phase.fields_map.values()))

        print("First field ID:", first_field.id)
        print("First field type:", first_field.type)

        # O(1)
        field_by_id = phase.getField(first_field.id)
        print("Access via getField:", field_by_id.id)

        # __getitem__
        field_direct = phase[first_field.id]
        print("Access via []:", field_direct.id)

    # ============================================================
    # Parse errors visibility
    # ============================================================
    if hasattr(phase, "_parse_errors"):
        print("Parse errors:", len(phase._parse_errors))

    print("✔ getPhaseModel OK")


def testPhaseCustomQuery(api: Pipefy, phase_id: str) -> None:
    """
    Test phase retrieval with custom query.

    :param api: Pipefy
    :param phase_id: str

    :return: None
    """
    print("\n=== TEST: getPhaseModel (custom query) ===")

    query_body = """
        id
        name

        cards(first: 5) {
            edges {
                node {
                    id
                    title
                }
            }
        }
    """

    phase = api.getPhaseModel(phase_id, query_body=query_body)

    print("ID:", phase.id)
    print("Name:", phase.name)

    print("Cards preview:", len(phase.cards_preview))

    if phase.cards_preview:
        print("First card:", phase.cards_preview[0])

    print("✔ getPhaseModel (custom query) OK")



# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    api = getApi()

    PHASE_ID = "83728"

    try:
        # ========================================================
        # CORE FLOW
        # ========================================================
        testPhaseRaw(api, PHASE_ID)
        testPhaseStructured(api, PHASE_ID)
        testPhaseModel(api, PHASE_ID)

        # ========================================================
        # ADVANCED
        # ========================================================
        testPhaseCustomQuery(api, PHASE_ID)

        print("\n🎯 ALL TESTS EXECUTED")

    except Exception as error:
        print("\n❌ TEST FAILED:")
        print(error)
        print(traceback.format_exc())