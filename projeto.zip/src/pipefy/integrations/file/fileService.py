# ============================================================
# Dependencies
# ============================================================
from typing import Dict, Any, Optional
import requests

from pipefy.client.httpClient import PipefyHttpClient
from pipefy.exceptions.exceptions import RequestError
from pipefy.service.cardService import CardService
from pipefy.integrations.file.fileUploadResult import FileUploadResult


class FileService:
    """
    Service responsible for file upload and download operations.

    This service handles integration with external storage systems
    using presigned URLs provided by Pipefy.

    Responsibilities:
        - Generate presigned URLs
        - Upload files to storage
        - Attach files to card fields
        - Download attachments from cards

    This service does NOT follow the RAW → STRUCTURED → MODEL pattern,
    as it operates outside the GraphQL domain.

    :param client: PipefyHttpClient = HTTP client instance
    :param card_service: CardService = Card service dependency
    """

    def __init__(
        self,
        client: PipefyHttpClient,
        card_service: CardService
    ) -> None:
        """
        Initialize FileService.

        :param client: PipefyHttpClient = HTTP client instance
        :param card_service: CardService = Card service dependency
        """
        self._client: PipefyHttpClient = client
        self._card_service: CardService = card_service

    # ============================================================
    # PRIVATE METHODS
    # ============================================================

    def _createPresignedUrl(
        self,
        file_name: str,
        organization_id: int
    ) -> Dict[str, Any]:
        """
        Create a presigned URL for file upload.

        :param file_name: str = Name of the file to upload
        :param organization_id: int = Organization identifier

        :return: dict = Raw API response containing upload and download URLs

        :raises RequestError:
            When request execution fails
        :raises RequestError:
            When response structure is invalid
        """
        try:
            query: str = f"""
            mutation {{
                createPresignedUrl(
                    input: {{
                        organizationId: {organization_id},
                        fileName: "{file_name}"
                    }}
                ) {{
                    url
                    downloadUrl
                }}
            }}
            """

            return self._client.sendRequest(query)

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: _createPresignedUrl\n"
                f"Error: {str(exc)}"
            ) from exc

    def _uploadToStorage(
        self,
        url: str,
        file_bytes: bytes
    ) -> None:
        """
        Upload file content to external storage.

        :param url: str = Presigned upload URL
        :param file_bytes: bytes = Binary file content

        :return: None

        :raises RequestError:
            When upload request fails
        :raises RequestError:
            When storage returns an unexpected status code
        """
        try:
            response = requests.put(url, data=file_bytes)

            if response.status_code not in (200, 201):
                raise ValueError(
                    f"Upload failed with status {response.status_code}: {response.text}"
                )

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: _uploadToStorage\n"
                f"Error: {str(exc)}"
            ) from exc

    def _extractFilePath(self, upload_url: str) -> str:
        """
        Extract file path from presigned upload URL.

        :param upload_url: str = Presigned upload URL

        :return: str = Extracted file path

        :raises RequestError:
            When URL parsing fails
        """
        try:
            return upload_url.split("?")[0]

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: _extractFilePath\n"
                f"Error: {str(exc)}"
            ) from exc

    def _attachToCard(
            self,
            card_id: str,
            field_id: str,
            file_path: str
    ) -> None:
        """
        Attach uploaded file to a card field.

        This method updates a single card field using the CardService
        high-level API, ensuring correct payload formatting.

        :param card_id: str = Card identifier
        :param field_id: str = Field identifier (attachment field)
        :param file_path: str = Uploaded file path

        :return: None

        :raises RequestError:
            When card update fails

        :example:
            >>> callable(FileService._attachToCard)
            True
        """
        try:
            self._card_service.updateField(
                card_id=card_id,
                field_id=field_id,
                value=file_path
            )

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: _attachToCard\n"
                f"Error: {str(exc)}"
            ) from exc
    # ============================================================
    # PUBLIC METHODS
    # ============================================================

    def uploadFile(
        self,
        file_name: str,
        file_bytes: bytes,
        card_id: str,
        field_id: str,
        organization_id: int
    ) -> FileUploadResult:
        """
        Upload a file and attach it to a card field.

        Execution flow:
            1. Generate presigned URL
            2. Upload file to storage
            3. Attach file to card field

        :param file_name: str = File name
        :param file_bytes: bytes = Binary file content
        :param card_id: str = Card identifier
        :param field_id: str = Field identifier (attachment field)
        :param organization_id: int = Organization identifier

        :return: FileUploadResult = Result object with upload metadata

        :raises RequestError:
            When presigned URL generation fails
        :raises RequestError:
            When upload to storage fails
        :raises RequestError:
            When card update fails
        :raises RequestError:
            When response parsing fails

        :example:
            >>> callable(FileService.uploadFile)
            True
        """
        try:
            presigned: Dict[str, Any] = self._createPresignedUrl(
                file_name,
                organization_id
            )

            data: Dict[str, Any] = presigned.get("data", {}).get("createPresignedUrl", {})

            upload_url: Optional[str] = data.get("url")
            download_url: Optional[str] = data.get("downloadUrl")

            if not upload_url:
                raise ValueError("Missing upload URL in response")

            self._uploadToStorage(upload_url, file_bytes)

            file_path: str = self._extractFilePath(upload_url)

            self._attachToCard(card_id, field_id, file_path)

            return FileUploadResult(
                file_path=file_path,
                download_url=download_url,
                success=True
            )

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: uploadFile\n"
                f"Error: {str(exc)}"
            ) from exc

    def downloadAllAttachments(
        self,
        card_id: str
    ) -> Dict[str, bytes]:
        """
        Download all attachments from a card.

        :param card_id: str = Card identifier

        :return: dict[str, bytes] = Mapping of file URL to binary content

        :raises RequestError:
            When card retrieval fails
        :raises RequestError:
            When file download fails
        """
        try:
            query_body: str = """
                attachments {
                    url
                }
            """

            card = self._card_service.getCardModel(
                card_id,
                query_body=query_body
            )

            files: Dict[str, bytes] = {}

            for attachment in getattr(card, "attachments", []):
                url: Optional[str] = attachment.get("url")

                if not url:
                    continue

                response = requests.get(url)

                if response.status_code == 200:
                    files[url] = response.content

            return files

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: downloadAllAttachments\n"
                f"Error: {str(exc)}"
            ) from exc


# ============================================================
# MAIN TEST
# ============================================================

if __name__ == "__main__":
    """
    Simple execution test.

    This block does not perform real API calls, but validates
    that the service is correctly instantiated.
    """
    print("FileService loaded successfully.")