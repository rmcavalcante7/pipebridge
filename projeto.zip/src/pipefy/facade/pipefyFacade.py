# ============================================================
# Dependencies
# ============================================================
import sys
from typing import List, Optional, Any, Dict

from pipefy.client.httpClient import PipefyHttpClient
from pipefy.integrations.file.fileUploadResult import FileUploadResult
from pipefy.integrations.file.fileService import FileService
from pipefy.service.cardService import CardService
from pipefy.service.pipeService import PipeService
from pipefy.service.phaseService import PhaseService
from pipefy.models.phase import Phase
from pipefy.models.card import Card

# ============================================================
# Custom Exceptions
# ============================================================


class PipefyInitializationError(Exception):
    """
    Exception raised when Pipefy facade initialization fails.
    """
    pass


# ============================================================
# Facade
# ============================================================


class Pipefy:
    """
    Facade for Pipefy SDK.

    Provides a high-level interface for interacting with Pipefy services,
    abstracting internal layers such as HTTP client and services.

    This class aggregates:
    - CardService
    - PipeService
    - FileService

    :param token: str = API authentication token

    :raises PipefyInitializationError:
        When token is invalid or initialization fails

    :example:
        >>> from pipefy.facade.pipefyFacade import Pipefy
        >>> api = Pipefy("your_token")
        >>> isinstance(api.card, CardService)
        True
    """

    # ============================================================
    # Constructor
    # ============================================================

    def __init__(self, token: str) -> None:
        if not isinstance(token, str) or not token.strip():
            raise PipefyInitializationError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: __init__\n"
                f"Error: Invalid token provided"
            )

        try:
            self._client: PipefyHttpClient = PipefyHttpClient(token)

            # Services
            self.card: CardService = CardService(self._client)
            self.pipe: PipeService = PipeService(self._client)
            self.file: FileService = FileService(self._client, self.card)
            self.phase: PhaseService = PhaseService(self._client)

        except Exception as exc:
            raise PipefyInitializationError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: __init__\n"
                f"Error: {str(exc)}"
            ) from exc

    # ============================================================
    # Convenience Methods
    # ============================================================

    def createCard(
            self,
            pipe_id: str,
            title: str,
            fields: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create a new card.

        :param pipe_id: str = Pipe identifier
        :param title: str = Card title
        :param fields: dict[str, Any] | None = Field values mapped by field_id

        :return: dict = Created card data

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy.facade.pipefyFacade import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.createCard)
            True
        """
        return self.card.createCard(pipe_id, title, fields)

    def getCardStructured(
            self,
            card_id: str,
            query_body: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Retrieve structured card data.

        :param card_id: str = Card identifier
        :param query_body: str | None = Optional GraphQL fields

        :return: dict = Structured card data

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.getCardStructured)
            True
        """
        return self.card.getCardStructured(card_id, query_body)

    def getRawCard(
            self,
            card_id: str,
            query_body: str
    ) -> Dict[str, Any]:
        """
        Execute a raw GraphQL query for a card.

        This method exposes the low-level CardService.getRawCard, allowing full
        control over the GraphQL query structure.

        It is intended for advanced usage where the SDK structured methods
        are not sufficient.

        :param card_id: str = Card ID
        :param query_body: str = GraphQL body inside `card { ... }`

        :return: dict = Raw API response

        :raises RequestError:
            When request execution fails

        :example:
            >>> from pipefy import Pipefy
            >>> sdk = Pipefy("token")
            >>> result = sdk.getRawCard("1","id title")
            >>> isinstance(result, dict)
            True
        """
        return self.card.getRawCard(card_id, query_body)

    def getCardModel(
            self,
            card_id: str,
            query_body: Optional[str] = None
    ) -> "Card":
        """
        Retrieve a card as a typed Card model.

        :param card_id: str = Card identifier
        :param query_body: str | None = Optional GraphQL fields

        :return: Card

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.getCardModel)
            True
        """
        return self.card.getCardModel(
            card_id=card_id,
            query_body=query_body
        )

    def getPhaseStructured(
            self,
            phase_id: str
    ) -> Dict[str, Any]:
        """
        Retrieve a phase with structured data.

        :param phase_id: str = Phase identifier

        :return: dict = Structured phase data

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.getPhaseStructured)
            True
        """
        return self.phase.getPhaseStructured(phase_id)

    def getPhaseModel(
            self,
            phase_id: str,
            query_body: Optional[str] = None
    ) -> "Phase":
        """
        Retrieve a Phase as a strongly-typed model.

        :param phase_id: str = Phase identifier
        :param query_body: str | None = Optional GraphQL fields

        :return: Phase = Parsed Phase model

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.getPhaseModel)
            True
        """
        return self.phase.getPhaseModel(
            phase_id=phase_id,
            query_body=query_body
        )

    def getPhaseFullModel(self, phase_id: str) -> "Phase":
        """
        Retrieve full phase model.

        :param phase_id: str = Phase identifier

        :return: Phase = Parsed Phase model

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.getPhaseFullModel)
            True
        """
        return self.phase.getPhaseFullModel(phase_id)

    def getPhaseWithFieldsModel(
            self,
            phase_id: str
    ) -> "Phase":
        """
        Retrieve a phase including fields as a typed model.

        :param phase_id: str = Phase identifier

        :return: Phase = Parsed Phase model

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.getPhaseWithFieldsModel)
            True
        """
        return self.phase.getPhaseWithFieldsModel(phase_id)

    def uploadFile(
            self,
            file_name: str,
            file_bytes: bytes,
            card_id: str,
            field_id: str,
            organization_id: int
    ) -> FileUploadResult:
        """
        Upload a file to a card.

        This method delegates the upload process to FileService,
        returning detailed metadata about the uploaded file.

        :param file_name: str = File name
        :param file_bytes: bytes = File content
        :param card_id: str = Card identifier
        :param field_id: str = Field identifier
        :param organization_id: int = Organization ID

        :return: FileUploadResult = Upload result metadata

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy.facade.pipefyFacade import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.uploadFile)
            True
        """
        return self.file.uploadFile(
            file_name=file_name,
            file_bytes=file_bytes,
            card_id=card_id,
            field_id=field_id,
            organization_id=organization_id
        )

    def downloadAttachments(
            self,
            card_id: str
    ) -> Dict[str, bytes]:
        """
        Download all attachments from a card.

        :param card_id: str = Card identifier

        :return: dict[str, bytes] = Mapping of URL to file content

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy.facade.pipefyFacade import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.downloadAttachments)
            True
        """
        return self.file.downloadAllAttachments(card_id)

    def getPipeStructured(
            self,
            pipe_id: str,
            query_body: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Retrieve structured pipe data.

        :param pipe_id: str = Pipe identifier
        :param query_body: str | None = Optional GraphQL fields

        :return: dict = Structured pipe data

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.getPipeStructured)
            True
        """
        return self.pipe.getPipeStructured(
            pipe_id=pipe_id,
            query_body=query_body
        )

    def getPipeModel(
            self,
            pipe_id: str,
            query_body: Optional[str] = None
    ) -> "Pipe":
        """
        Retrieve pipe as a strongly-typed model.

        :param pipe_id: str = Pipe identifier
        :param query_body: str | None = Optional GraphQL fields

        :return: Pipe

        :raises Exception:
            Propagates underlying service exceptions

        :example:
            >>> from pipefy import Pipefy
            >>> api = Pipefy("token")
            >>> callable(api.getPipeModel)
            True
        """
        return self.pipe.getPipeModel(
            pipe_id=pipe_id,
            query_body=query_body
        )

# ============================================================
# Main (Usage Example)
# ============================================================
#
# if __name__ == "__main__":
#     try:
#         TOKEN = "your_token_here"
#
#         api = Pipefy(TOKEN)
#
#         # Example: get card
#         card = api.getCard("123")
#         print(card)
#
#         # Example: get pipe info via service
#         pipe_info = api.pipe.getPipeInfo("456")
#         print(pipe_info)
#
#     except Exception as error:
#         print("Error occurred:")
#         print(error)