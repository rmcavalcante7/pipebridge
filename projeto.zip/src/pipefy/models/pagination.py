# ============================================================
# Dependencies
# ============================================================
from typing import Any, Dict, Generic, List, Optional, TypeVar

from pipefy.models.base import BaseModel

T = TypeVar("T")


class PageInfo(BaseModel):
    """
    Represents GraphQL pagination metadata.
    """

    def __init__(
        self,
        hasNextPage: bool,
        endCursor: Optional[str] = None
    ) -> None:
        self.hasNextPage: bool = hasNextPage
        self.endCursor: Optional[str] = endCursor


class Edge(Generic[T]):
    """
    Represents a GraphQL edge.
    """

    def __init__(self, node: T) -> None:
        self.node: T = node


class PaginatedResponse(Generic[T]):
    """
    Represents a paginated GraphQL response.
    """

    def __init__(
        self,
        edges: List[Edge[T]],
        page_info: PageInfo
    ) -> None:
        self.edges: List[Edge[T]] = edges
        self.page_info: PageInfo = page_info

    def nodes(self) -> List[T]:
        """
        Extract all nodes from edges.

        :return: list[T]
        """
        return [edge.node for edge in self.edges]
