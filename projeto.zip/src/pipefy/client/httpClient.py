# ============================================================
# Dependencies
# ============================================================
import requests
import inspect
from typing import Any, Dict, Optional

from pipefy.exceptions.exceptions import RequestError, PipefyInvalidAuthToken, PipefyInvalidResponseError


class PipefyHttpClient:
    """
    Handles HTTP communication with Pipefy GraphQL API.

    This class is responsible for:
    - Sending HTTP requests to Pipefy
    - Handling transport-level errors
    - Returning raw API responses

    It does NOT:
    - Apply business rules
    - Transform domain data

    :example:
        >>> client = PipefyHttpClient("your_token")
        >>> response = client.sendRequest("{ me { id } }")
        >>> isinstance(response, dict)
        True
    """

    BASE_URL: str = "https://accenture.pipefy.com/queries"

    def __init__(self, auth_key: str) -> None:
        """
        Initialize HTTP client.

        :param auth_key: str = API authentication token

        :raises RequestError:
            When auth_key is invalid or empty

        :example:
            >>> client = PipefyHttpClient("your_token")
        """
        if not auth_key or not isinstance(auth_key, str):
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: {inspect.currentframe().f_code.co_name}\n"
                f"Error: Invalid auth_key"
            )

        self._headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {auth_key}"
        }

    def sendRequest(
        self,
        query: str,
        variables: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Sends a GraphQL request to Pipefy API.

        This method handles:
        - Payload construction
        - HTTP request execution
        - Basic GraphQL error detection

        :param query: str = GraphQL query string
        :param variables: dict | None = Optional GraphQL variables

        :return: dict = Raw API response

        :raises RequestError:
            When HTTP request fails
        :raises RequestError:
            When GraphQL returns errors

        :example:
            >>> client = PipefyHttpClient("your_token")
            >>> query = "{ me { id } }"
            >>> response = client.sendRequest(query)
            >>> isinstance(response, dict)
            True
        """
        payload: Dict[str, Any] = {"query": query}

        if variables:
            payload["variables"] = variables

        response = requests.post(
            self.BASE_URL,
            json=payload,
            headers=self._headers,
            timeout=30
        )

        try:
            json_response: Dict[str, Any] = response.json()
        except ValueError:
            raise PipefyInvalidResponseError()

        if not (200 <= response.status_code < 300):
            if "invalid_token" in str(json_response):
                raise PipefyInvalidAuthToken()

            if "error" in json_response.keys():
                if "errror_description" in json_response["error"]:
                    error_msg = json_response['error_description']
                else:
                    error_msg = str(json_response)
                raise RequestError(
                    f"Class: {self.__class__.__name__}\n"
                    f"Method: {inspect.currentframe().f_code.co_name}\n"
                    f"Error: GraphQL Error:\n{error_msg}"
                )
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: {inspect.currentframe().f_code.co_name}\n"    
                f"Error: GraphQL Error:\n{json_response}"
            )

        return json_response



# ============================================================
# Main (Usage Example)
# ============================================================

if __name__ == "__main__":
    """
    Simple execution example demonstrating HTTP client usage.
    """

    TOKEN = ""
    try:
        client = PipefyHttpClient(TOKEN)

        query = """
        {
            me {
                id
            }
        }
        """

        response = client.sendRequest(query)

        print("API Response:")
        print(response)

    except RequestError as error:
        print("Error occurred:")
        print(error)