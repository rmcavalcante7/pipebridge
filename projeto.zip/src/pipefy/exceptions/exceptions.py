# ============================================================
# Dependencies:
# - None
# ============================================================

from __future__ import annotations

import inspect


# ============================================================
# Base Exceptions
# ============================================================

class PipefyError(Exception):
    """
    Base exception for all Pipefy client errors.

    This exception should be used as the root for all domain-specific
    errors raised within the SDK.

    :example:
        >>> raise PipefyError("Generic error")
    """

class PipefyInvalidAuthToken(PipefyError):
    """
    Exception raised for invalid authentication tokens.
    """


class PipefyHttpError(PipefyError):
    """
    Exception raised for HTTP-related failures.

    :example:
        >>> raise PipefyHttpError("Request failed")
    """


class PipefyValidationError(PipefyError):
    """
    Exception raised for validation errors.

    :example:
        >>> raise PipefyValidationError("Invalid input")
    """


class PipefyResponseError(PipefyError):
    """
    Exception raised when API response is invalid or unexpected.

    :example:
        >>> raise PipefyResponseError("Malformed response")
    """

class PipefyInvalidResponseError(PipefyResponseError):
    """
    Exception raised when pipfey API doesn't return a json as response.

    :example:
        >>> raise PipefyInvalidResponseError("Response schema mismatch")
    """

class RequestError(PipefyError):
    """
    Exception raised for HTTP or GraphQL request failures.

    This exception is kept for backward compatibility with existing modules.

    :example:
        >>> raise RequestError("Request failed")
    """

class InvalidParameterError(PipefyError):
    """
    Exception raised when an invalid parameter is provided.

    This is commonly used for:
    - Invalid query attributes
    - Unsupported field names
    - Incorrect input values

    :example:
        >>> raise InvalidParameterError("Invalid field")
    """
# ============================================================
# Helper Functions
# ============================================================

def buildErrorMessage(
    instance: object,
    method_name: str,
    message: str
) -> str:
    """
    Builds a standardized error message including class and method context.

    This function ensures all exceptions follow a consistent format,
    improving observability and debugging.

    :param instance: object = Instance where the error occurred
    :param method_name: str = Name of the method where the error occurred
    :param message: str = Original error message

    :return: str = Formatted error message

    :example:
        >>> class Example:
        ...     def run(self):
        ...         raise Exception(
        ...             buildErrorMessage(self, "run", "Something went wrong")
        ...         )
    """
    return (
        f"Class: {instance.__class__.__name__}\n"
        f"Method: {method_name}\n"
        f"Error: {message}"
    )


def raiseWithContext(
    instance: object,
    exc: Exception
) -> None:
    """
    Re-raises an exception with enriched contextual information.

    This helper should be used to wrap lower-level exceptions while preserving
    the original traceback using 'from exc'.

    :param instance: object = Instance where the exception occurred
    :param exc: Exception = Original exception

    :raises PipefyError:
        Always raises a PipefyError with contextual information

    :example:
        >>> try:
        ...     int("invalid")
        ... except Exception as e:
        ...     raiseWithContext(object(), e)
    """
    method_name: str = inspect.currentframe().f_back.f_code.co_name  # type: ignore

    raise PipefyError(
        buildErrorMessage(instance, method_name, str(exc))
    ) from exc


# ============================================================
# Dependencies
# ============================================================
from typing import List


class ValidationError(Exception):
    """
    Represents a validation failure when comparing Card data
    against Phase schema.

    :param message: str = Error message
    :param fields: list[str] = Fields that failed validation
    """

    def __init__(self, message: str, fields: List[str]) -> None:
        super().__init__(message)
        self.fields: List[str] = fields


# ============================================================
# Main (Usage Example)
# ============================================================

if __name__ == "__main__":
    """
    Simple execution example demonstrating exception usage.
    """

    class ExampleService:
        def execute(self) -> None:
            """
            Example method that raises a contextualized exception.

            :raises PipefyError:
                When execution fails

            :example:
                >>> service = ExampleService()
                >>> service.execute()
            """
            try:
                int("not_a_number")
            except Exception as exc:
                raiseWithContext(self, exc)

    service = ExampleService()

    try:
        service.execute()
    except PipefyError as error:
        print("Captured PipefyError:")
        print(error)