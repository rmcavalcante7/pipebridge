# ============================================================
# Dependencies
# ============================================================
from typing import Dict, Any, Optional
import inspect

from pipefy.client.httpClient import PipefyHttpClient
from pipefy.exceptions.exceptions import RequestError
from pipefy.models.phase import Phase


class PhaseService:
    """
    Service responsible for handling Phase operations.

    This service provides methods to retrieve raw, structured,
    and model-based representations of Pipefy Phases.

    It follows a layered architecture:
        RAW → STRUCTURED → MODEL

    :param client: PipefyHttpClient = HTTP client instance
    """

    def __init__(self, client: PipefyHttpClient) -> None:
        self._client: PipefyHttpClient = client

    # ============================================================
    # RAW
    # ============================================================

    def getPhaseRaw(self, phase_id: str, query_body: str) -> Dict[str, Any]:
        """
        Retrieve raw phase data using a custom GraphQL query body.

        This method provides full flexibility for defining which fields
        should be retrieved from the Pipefy API.

        :param phase_id: str = Phase identifier
        :param query_body: str = GraphQL fields to retrieve

        :return: dict = Raw API response

        :raises RequestError:
            When request execution fails
        :raises RequestError:
            When query construction fails

        :example:
            >>> service = PhaseService(PipefyHttpClient("token"))
            >>> callable(service.getPhaseRaw)
            True
        """
        try:
            query: str = f"""
            {{
                phase(id: "{phase_id}") {{
                    {query_body}
                }}
            }}
            """

            return self._client.sendRequest(query)

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: getPhaseRaw\n"
                f"Error: {str(exc)}"
            ) from exc

    # ============================================================
    # STRUCTURED
    # ============================================================

    def getPhaseStructured(
        self,
        phase_id: str,
        query_body: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Retrieve structured phase data.

        This method abstracts GraphQL complexity and returns a cleaned,
        consistent dictionary containing the requested phase data.

        If no query_body is provided, a default structure including
        fields metadata is used.

        :param phase_id: str = Phase identifier
        :param query_body: str | None = Optional GraphQL fields

        :return: dict = Structured phase data

        :raises RequestError:
            When request execution fails
        :raises RequestError:
            When response structure is invalid

        :example:
            >>> service = PhaseService(PipefyHttpClient("token"))
            >>> callable(service.getPhaseStructured)
            True
        """
        try:
            if not query_body:
                query_body = """
                    id
                    name

                    fields {
                        id
                        label
                        type
                        required
                        description
                        options
                    }
                """

            response: Dict[str, Any] = self.getPhaseRaw(phase_id, query_body)

            phase_data: Dict[str, Any] = (
                response
                .get("data", {})
                .get("phase", {})
            )

            if not phase_data:
                raise ValueError("Phase not found in response")

            return phase_data

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: getPhaseStructured\n"
                f"Error: {str(exc)}"
            ) from exc

    # ============================================================
    # MODEL
    # ============================================================

    def getPhaseModel(
        self,
        phase_id: str,
        query_body: Optional[str] = None
    ) -> Phase:
        """
        Retrieve a Phase as a strongly-typed model.

        This method converts structured phase data into a Phase object,
        enabling advanced access patterns such as O(1) field lookup.

        :param phase_id: str = Phase identifier
        :param query_body: str | None = Optional GraphQL fields

        :return: Phase = Parsed Phase model

        :raises RequestError:
            When request execution fails
        :raises RequestError:
            When parsing fails

        :example:
            >>> service = PhaseService(PipefyHttpClient("token"))
            >>> callable(service.getPhaseModel)
            True
        """
        try:
            phase_data: Dict[str, Any] = self.getPhaseStructured(
                phase_id,
                query_body
            )

            if not phase_data:
                raise ValueError("Empty pahse data returned from getPhaseStructured")

            return Phase.fromDict(phase_data)

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: getPhaseModel\n"
                f"Error: {str(exc)}"
            ) from exc


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":
    client = PipefyHttpClient("your_token_here")
    service = PhaseService(client)

    try:
        phase = service.getPhaseModel("123456")

        print("ID:", phase.id)
        print("Name:", phase.name)

        print("Fields count:", len(phase.fields))

        if phase.fields:
            first_field = phase.fields[0]
            print("First field:", first_field.id)

        print("✔ PhaseService OK")

    except Exception as e:
        print("❌ Error:", e)