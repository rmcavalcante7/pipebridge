# ============================================================
# Dependencies
# ============================================================
from typing import Dict, Any, Optional
import inspect

from pipefy.client.httpClient import PipefyHttpClient
from pipefy.exceptions.exceptions import RequestError
from pipefy.models.pipe import Pipe


class PipeService:
    """
    Service responsible for Pipe operations.

    This service follows a layered architecture:

        RAW → STRUCTURED → MODEL

    It provides a unified and flexible interface to retrieve
    pipe data, including phases, labels, and users.

    :param client: PipefyHttpClient = HTTP client instance
    """

    def __init__(self, client: PipefyHttpClient) -> None:
        self._client: PipefyHttpClient = client

    # ============================================================
    # RAW
    # ============================================================

    def getPipeRaw(self, pipe_id: str, query_body: str) -> Dict[str, Any]:
        """
        Retrieve raw pipe data using a custom GraphQL query.

        :param pipe_id: str = Pipe identifier
        :param query_body: str = GraphQL fields to retrieve

        :return: dict = Raw API response

        :raises RequestError:
            When request execution fails
        :raises RequestError:
            When query construction fails

        :example:
            >>> service = PipeService(PipefyHttpClient("token"))
            >>> callable(service.getPipeRaw)
            True
        """
        try:
            query: str = f"""
            {{
                pipe(id: "{pipe_id}") {{
                    {query_body}
                }}
            }}
            """

            return self._client.sendRequest(query)

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: getPipeRaw\n"
                f"Error: {str(exc)}"
            ) from exc

    # ============================================================
    # STRUCTURED
    # ============================================================

    def getPipeStructured(
        self,
        pipe_id: str,
        query_body: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Retrieve structured pipe data.

        This method abstracts GraphQL complexity and returns a cleaned,
        consistent dictionary representing a pipe.

        If no query_body is provided, a default query including
        phases, labels, users, and card count is used.

        :param pipe_id: str = Pipe identifier
        :param query_body: str | None = Optional GraphQL fields

        :return: dict = Structured pipe data

        :raises RequestError:
            When request execution fails
        :raises RequestError:
            When response structure is invalid

        :example:
            >>> service = PipeService(PipefyHttpClient("token"))
            >>> callable(service.getPipeStructured)
            True
        """
        try:
            if not query_body:
                query_body = """
                    id
                    name
                    cards_count

                    labels {
                        id
                        name
                        color
                    }

                    users {
                        id
                        name
                        email
                    }

                    phases {
                        id
                        name
                    }
                """

            response: Dict[str, Any] = self.getPipeRaw(pipe_id, query_body)

            pipe_data: Dict[str, Any] = (
                response
                .get("data", {})
                .get("pipe", {})
            )

            if not pipe_data:
                raise ValueError("Pipe not found in response")

            return pipe_data

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: getPipeStructured\n"
                f"Error: {str(exc)}"
            ) from exc

    # ============================================================
    # MODEL
    # ============================================================

    def getPipeModel(
        self,
        pipe_id: str,
        query_body: Optional[str] = None
    ) -> Pipe:
        """
        Retrieve a Pipe as a strongly-typed model.

        This method converts structured pipe data into a Pipe object,
        enabling direct access to phases, labels, and users without loops.

        :param pipe_id: str = Pipe identifier
        :param query_body: str | None = Optional GraphQL fields

        :return: Pipe = Parsed Pipe model

        :raises RequestError:
            When request execution fails
        :raises RequestError:
            When parsing fails

        :example:
            >>> service = PipeService(PipefyHttpClient("token"))
            >>> callable(service.getPipeModel)
            True
        """
        try:
            pipe_data: Dict[str, Any] = self.getPipeStructured(
                pipe_id,
                query_body
            )

            return Pipe.fromDict(pipe_data)

        except Exception as exc:
            raise RequestError(
                f"Class: {self.__class__.__name__}\n"
                f"Method: getPipeModel\n"
                f"Error: {str(exc)}"
            ) from exc


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":
    client = PipefyHttpClient("your_token_here")
    service = PipeService(client)

    try:
        pipe = service.getPipeModel("123456")

        print("ID:", pipe.id)
        print("Name:", pipe.name)

        print("Phases:", len(pipe.phases))
        print("Labels:", len(pipe.labels))
        print("Users:", len(pipe.users))

        if pipe.phases:
            first_phase = pipe.phases[0]
            print("First phase:", first_phase.id)

        print("✔ PipeService OK")

    except Exception as e:
        print("❌ Error:", e)