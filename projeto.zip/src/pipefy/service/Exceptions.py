# ============================================================
# Dependencies
# ============================================================
from typing import Optional, Dict, Any


# ============================================================
# Base Exception
# ============================================================


class PipefyError(Exception):
    """
    Base exception for all Pipefy SDK errors.

    Provides structured error information for debugging,
    observability, and future integrations.

    :param message: str = Human-readable error message
    :param code: str | None = Machine-readable error code
    :param context: dict | None = Additional contextual data

    :example:
        >>> raise PipefyError("Generic error")
    """

    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        super().__init__(message)
        self.message: str = message
        self.code: Optional[str] = code
        self.context: Dict[str, Any] = context or {}

    def __str__(self) -> str:
        base = f"[{self.code}] {self.message}" if self.code else self.message
        if self.context:
            return f"{base} | context={self.context}"
        return base


# ============================================================
# Validation Errors
# ============================================================


class ValidationError(PipefyError):
    """
    Raised when input validation fails.

    :example:
        >>> raise ValidationError("Invalid parameter", code="VALIDATION_ERROR")
    """


class MissingParameterError(ValidationError):
    """
    Raised when a required parameter is missing.
    """


class InvalidParameterError(ValidationError):
    """
    Raised when a parameter has invalid value or format.
    """


# ============================================================
# Request / Transport Errors
# ============================================================


class PipefyRequestError(PipefyError):
    """
    Raised when an HTTP request fails.

    :example:
        >>> raise PipefyRequestError("Request failed", code="REQUEST_ERROR")
    """


class TimeoutError(PipefyRequestError):
    """
    Raised when request times out.
    """


class AuthenticationError(PipefyRequestError):
    """
    Raised when authentication fails.
    """


class AuthorizationError(PipefyRequestError):
    """
    Raised when user is not authorized.
    """


# ============================================================
# Response Errors
# ============================================================


class InvalidResponseError(PipefyError):
    """
    Raised when API response structure is invalid.
    """


class UnexpectedResponseError(PipefyError):
    """
    Raised when API response does not match expected contract.
    """


# ============================================================
# Domain Errors (Card)
# ============================================================


class CardError(PipefyError):
    """
    Base error for card-related operations.
    """


class CardNotFoundError(CardError):
    """
    Raised when a card is not found.
    """


class CardCreationError(CardError):
    """
    Raised when card creation fails.
    """


class CardUpdateError(CardError):
    """
    Raised when card update fails.
    """


class CardDeletionError(CardError):
    """
    Raised when card deletion fails.
    """


class CardRelationError(CardError):
    """
    Raised when card relation fails.
    """


# ============================================================
# Pagination Errors
# ============================================================


class PaginationError(PipefyError):
    """
    Raised when pagination fails or is inconsistent.
    """


# ============================================================
# Helper Factory (Optional but powerful)
# ============================================================


class ErrorFactory:
    """
    Factory for creating standardized exceptions.

    Centralizes error creation logic for consistency.

    :example:
        >>> raise ErrorFactory.validation("Invalid field")
    """

    @staticmethod
    def validation(message: str, context: Optional[Dict[str, Any]] = None) -> ValidationError:
        return ValidationError(message, code="VALIDATION_ERROR", context=context)

    @staticmethod
    def request(message: str, context: Optional[Dict[str, Any]] = None) -> PipefyRequestError:
        return PipefyRequestError(message, code="REQUEST_ERROR", context=context)

    @staticmethod
    def response(message: str, context: Optional[Dict[str, Any]] = None) -> InvalidResponseError:
        return InvalidResponseError(message, code="INVALID_RESPONSE", context=context)

    @staticmethod
    def card_not_found(card_id: str) -> CardNotFoundError:
        return CardNotFoundError(
            message=f"Card '{card_id}' not found",
            code="CARD_NOT_FOUND",
            context={"card_id": card_id}
        )

    @staticmethod
    def card_creation(message: str, context: Optional[Dict[str, Any]] = None) -> CardCreationError:
        return CardCreationError(message, code="CARD_CREATION_FAILED", context=context)

    @staticmethod
    def pagination(message: str, context: Optional[Dict[str, Any]] = None) -> PaginationError:
        return PaginationError(message, code="PAGINATION_ERROR", context=context)


# ============================================================
# Main (Example)
# ============================================================

if __name__ == "__main__":
    try:
        raise ErrorFactory.card_not_found("123")
    except PipefyError as error:
        print(str(error))