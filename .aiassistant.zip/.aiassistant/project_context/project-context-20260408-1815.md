---
apply: always
---

# CONTEXTO PERSISTIDO DO PROJETO - infra-core-sdk

## Leitura obrigatoria

Este arquivo registra o estado consolidado mais recente do projeto apos a estabilizacao inicial do pacote para distribuicao.

Ele deve ser lido no inicio de qualquer nova sessao relevante para preservar:

- o estado real do SDK
- o que ja foi corrigido nesta fase
- o que ainda falta validar fora desta maquina
- a ordem correta das proximas melhorias

Regra de leitura:

- o foco imediato desta fase foi confiabilidade de distribuicao
- nao tratar a base como pronta para refatoracao ampla
- preservar o que ja foi estabilizado antes de expandir escopo

---

## Identidade atual do projeto

- projeto: `infra-core-sdk`
- natureza: biblioteca Python distribuivel
- objetivo funcional: fornecer root resolution, path management e credenciais criptografadas para outros projetos Python

Arquitetura central:

- `core/root`: descoberta da raiz do projeto consumidor
- `core/path`: definicao, configuracao e operacoes de path
- `credentials`: modelos, persistencia, setup e loading
- `security`: criptografia, com implementacao pronta em Fernet

---

## Problema real que motivou esta fase

O SDK funcionava localmente neste repositorio, mas apresentou problema em outra maquina apos `pip install`.

Sintomas reportados:

- imports publicos insuficientes
- falha para descobrir corretamente a raiz do projeto consumidor

Diagnostico consolidado:

- a API publica estava incompleta
- `RootResolver` dependia excessivamente de `cwd`
- o pacote estava mais validado no modo "codigo aberto no repositorio" do que no modo "instalado em site-packages"

---

## Correcoes implementadas nesta fase

### 1. Root resolution

Arquivos principais:

- `src/infra_core/core/root/root_config.py`
- `src/infra_core/core/root/root_resolver.py`
- `src/infra_core/core/root/exceptions.py`

Correcoes aplicadas:

- `RootConfig` agora aceita `start_path`
- `RootResolver` tenta, em ordem:
  - `start_path` configurado
  - `cwd`
  - fallback pelo caminho do chamador quando o SDK esta instalado em `site-packages`
- foi criada `InvalidRootStartPathError`

Decisao importante:

- o fallback do chamador so deve atuar em contexto de pacote instalado, para nao mascarar erros durante desenvolvimento local

### 2. API publica via `__init__.py`

Arquivos principais:

- `src/infra_core/__init__.py`
- `src/infra_core/core/__init__.py`
- `src/infra_core/core/root/__init__.py`
- `src/infra_core/exceptions/__init__.py`
- `src/infra_core/credentials/exceptions/__init__.py`

Correcoes aplicadas:

- o topo do pacote agora expoe:
  - `CredentialsService`
  - `CredentialsLoader`
  - `CredentialsSetupService`
  - `PathConfig`
  - `PathManager`
  - `RootConfig`
  - `RootConfigProvider`
  - `RootResolver`
  - `FernetEncryption`
- subpacotes de `core.root`, `exceptions` e `credentials.exceptions` agora reexportam seus contratos adequados
- duplicacoes acidentais em `__init__.py` foram removidas

### 3. Correcao concreta em `credentials_service.py`

Arquivo principal:

- `src/infra_core/credentials/services/credentials_service.py`

Correcao aplicada:

- substituicao de `except FileNotFoundError, json.JSONDecodeError:` por `except (FileNotFoundError, json.JSONDecodeError):`

Leitura correta:

- esse era um ponto real de fragilidade e precisava ser corrigido antes de nova distribuicao

### 4. Limpeza de empacotamento

Arquivo principal:

- `MANIFEST.in`

Correcao aplicada:

- o `sdist` foi limitado para evitar incluir arquivos de IDE, testes, segredos, documentos auxiliares, zips e artefatos locais

Resultado pratico:

- os artefatos novos ficaram limpos e focados no conteudo distribuivel

---

## Validacao consolidada

Validado nesta maquina:

- suite local: `63 passed`
- imports publicos funcionando com `PYTHONPATH=src`
- wheel novo instalado na `.venv`
- imports publicos funcionando a partir de `site-packages`
- script consumidor fora do projeto resolvendo a raiz corretamente
- build novo gerado com sucesso
- `sdist` novo inspecionado e limpo

Artefatos atuais validos:

- `dist/infra_core_sdk-0.2.1.post0-py3-none-any.whl`
- `dist/infra_core_sdk-0.2.1.post0.tar.gz`

Artefatos antigos:

- foram removidos de `dist`

---

## O que ainda falta

O pacote esta pronto para validacao externa, mas ainda falta a confirmacao final fora desta maquina.

Pendencia objetiva:

1. instalar `dist/infra_core_sdk-0.2.1.post0-py3-none-any.whl` na outra maquina
2. executar o caso real que antes falhava
3. confirmar:
   - imports esperados
   - root resolution
   - setup e loading de credenciais no projeto consumidor

Regra importante:

- so depois dessa validacao externa considerar esta fase realmente encerrada

---

## Melhorias futuras recomendadas

### Prioridade alta

1. adicionar teste automatizado de smoke test do wheel instalado

Objetivo:

- validar importacao da API publica e root resolution a partir do artefato instalado, nao apenas do codigo-fonte

2. revisar a distribuicao para manter somente o necessario no pacote

Objetivo:

- garantir que o empacotamento continue limpo em futuras versoes

### Prioridade media

3. unificar a estrategia de excecoes de credenciais

Estado atual:

- existe `credentials_exceptions.py`
- existe tambem o pacote `credentials.exceptions`

Risco:

- API conceitualmente duplicada

4. revisar o uso de providers globais

Estado atual:

- `RootConfigProvider` e `PathConfigProvider` funcionam, mas mantem estado global

Melhoria desejada:

- permitir configuracao mais explicita por instancia em cenarios que precisem isolamento

5. melhorar a qualidade do README e encoding

Estado atual:

- ha caracteres mal renderizados em alguns arquivos

Melhoria desejada:

- documentacao mais clara e sem problemas de encoding

### Prioridade baixa

6. rever superficie publica do pacote como produto

Objetivo:

- definir de forma mais rigorosa o que e API publica estavel e o que e detalhe interno

7. adicionar validacoes de compatibilidade mais proximas do uso real

Exemplos:

- teste de install em ambiente limpo
- exemplo consumidor automatizado

---

## O que preservar

Preservar estas direcoes:

- mudanças incrementais
- foco em estabilidade antes de redesign
- API publica clara
- root resolution previsivel em contexto instalado
- empacotamento limpo

---

## O que nao fazer

Evitar especialmente:

- iniciar refatoracao grande antes da validacao final na outra maquina
- expandir mais a API publica sem criterio
- reintroduzir arquivos locais e artefatos de desenvolvimento no pacote distribuido
- misturar melhoria arquitetural ampla com correcao de distribuicao

---

## Ordem recomendada para continuar

1. validar o wheel novo na outra maquina
2. se passar, considerar a fase de estabilizacao encerrada
3. adicionar smoke test automatizado do wheel instalado
4. revisar excecoes e providers
5. melhorar documentacao e encoding
6. so depois discutir refatoracoes maiores

---

## Resumo curto para retomada futura

1. `infra-core-sdk` e um SDK Python distribuivel
2. o problema recente estava no uso via `pip install`
3. nesta fase foram corrigidos:
   - root resolution
   - API publica via `__init__.py`
   - `credentials_service.py`
   - empacotamento
4. a validacao local esta feita
5. falta apenas a confirmacao final na outra maquina
6. o proximo bloco de melhoria recomendado e smoke test do wheel instalado
