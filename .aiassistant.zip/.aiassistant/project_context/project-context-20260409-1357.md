---
apply: always
---

# CONTEXTO PERSISTIDO DO PROJETO - infra-core-sdk

## Leitura obrigatoria

Este arquivo registra o snapshot consolidado mais recente do projeto em `2026-04-09 13:57` no contexto local.

Ele deve ser lido no inicio de qualquer nova sessao relevante para preservar:

- o estado atual do SDK publicado
- o que ja foi validado na pratica
- a infraestrutura operacional criada no repositório
- o que ainda nao foi exercitado ou refinado

Regra de leitura:

- a fase critica de estabilizacao do pacote esta concluida
- o projeto agora entrou em uma fase de operacao e melhoria incremental
- qualquer proxima alteracao deve preservar a distribuicao validada da versao `0.2.1.post1`

---

## Estado atual resumido

- projeto: `infra-core-sdk`
- natureza: biblioteca Python distribuivel
- versao publicada de referencia: `0.2.1.post1`
- status: publicada no PyPI e validada em instalacao limpa

Pagina da versao validada:

- `https://pypi.org/project/infra-core-sdk/0.2.1.post1/`

---

## O que ja foi corrigido nesta fase

### Root resolution

Consolidado:

- `RootConfig` suporta `start_path`
- `RootResolver` usa:
  1. `start_path`
  2. `cwd`
  3. fallback pelo chamador quando instalado em `site-packages`

Arquivos principais:

- `src/infra_core/core/root/root_config.py`
- `src/infra_core/core/root/root_resolver.py`
- `src/infra_core/core/root/exceptions.py`

### API publica

Consolidado:

- o topo de `infra_core` expoe os principais contratos do SDK
- subpacotes relevantes tambem reexportam contratos selecionados

Arquivos principais:

- `src/infra_core/__init__.py`
- `src/infra_core/core/__init__.py`
- `src/infra_core/core/root/__init__.py`
- `src/infra_core/exceptions/__init__.py`
- `src/infra_core/credentials/exceptions/__init__.py`

### Credentials service

Consolidado:

- `credentials_service.py` foi corrigido no `except` que estava fragil/inconsistente para Python 3

### Empacotamento

Consolidado:

- `MANIFEST.in` limita o conteudo do `sdist`
- artefatos antigos foram limpos de `dist`

### README

Consolidado:

- o README foi refeito para comunicar melhor o potencial do SDK
- badges foram preservadas
- a documentacao foi alinhada com a API publica real
- a versao referenciada no README foi ajustada para `0.2.1.post1`

### Exemplo simples

Consolidado:

- existe um exemplo direto na raiz:
  - `example_simple_usage.py`

Esse exemplo mostra:

- definicao de classe de credenciais
- configuracao de root
- configuracao de paths
- setup com `FernetEncryption`
- load das credenciais

---

## O que ja foi validado

### Validacao local

Ja executado com sucesso:

- `python -m black .`
- `python -m mypy src`
- `python -m pytest`
- `python -m build`
- `python -m twine check dist/*`

Resultado importante:

- suite local validada com `63 passed`

### Validacao de release

Consolidado:

- tag `v0.2.1.post1` criada e enviada
- versao `0.2.1.post1` publicada no PyPI

### Validacao real do pacote publicado

Ja executado com sucesso:

- criacao de venv limpa temporaria
- `pip install infra-core-sdk==0.2.1.post1`
- imports publicos a partir de `site-packages`
- script consumidor fora do repositorio
- `RootResolver` funcionando com `cwd` externo
- `CredentialsSetupService(FernetEncryption)` funcionando
- `CredentialsLoader.load(...)` funcionando

Conclusao:

- o cenário real que motivou a fase foi efetivamente validado

---

## Infraestrutura operacional adicionada ao repositorio

### Workflow de publicacao

Arquivo:

- `.github/workflows/publish.yml`

Decisao atual:

- o fluxo desejado para futuras releases e:
  - validar localmente
  - commitar
  - criar tag `v*`
  - enviar a tag
  - deixar o GitHub Actions publicar no PyPI

Observacao importante:

- este workflow foi criado e commitado, mas ainda nao foi exercitado em uma release real
- a release `0.2.1.post1` foi publicada manualmente nesta sessao com `twine upload`

### Runbook de release

Arquivo:

- `.aiassistant/runbooks/release-pypi.md`

Papel:

- documentar o fluxo oficial de release por tag git

### Checklists

Arquivos:

- `.aiassistant/checklist/pre-release.md`
- `.aiassistant/checklist/post-release.md`
- `.aiassistant/checklist/consumer-validation.md`

Papel:

- reduzir variacao operacional
- tornar o processo de release e validacao repetivel

### Decisions

Arquivos:

- `.aiassistant/decisions/release-source-of-truth.md`
- `.aiassistant/decisions/pypi-release-strategy.md`
- `.aiassistant/decisions/public-api-surface.md`
- `.aiassistant/decisions/root-resolution-strategy.md`
- `.aiassistant/decisions/packaging-policy.md`

Papel:

- registrar as decisoes estruturais ja tomadas e testadas

### Gitignore da pasta .aiassistant

Consolidado:

- `project_context` continua fora do git
- `runbooks`, `decisions` e `checklist` agora podem ser versionados

---

## Commits recentes relevantes

Commits mais recentes que definem o estado atual:

- `cd46608` - `Update README for v0.2.1.post1`
- `8f50bbf` - `Add release workflow and operational docs`
- `9f655b7` - `Add project decisions documentation`

Leitura correta:

- esses commits marcam a transicao de um projeto apenas funcional para um projeto operado com processo de release mais explicito

---

## O que ainda falta ou merece atencao

### Pendencia operacional

O ponto mais importante que ainda nao foi exercitado na pratica e:

- o workflow `publish.yml` publicando uma release real a partir de tag git

Ele existe e esta alinhado com o processo desejado, mas ainda nao substituiu uma publicacao real completa.

### Melhorias futuras recomendadas

Prioridade alta:

1. exercitar uma release real usando apenas o fluxo por tag + GitHub Actions
2. adicionar smoke test automatizado do pacote instalado

Prioridade media:

3. revisar a estrategia de excecoes de credenciais
4. revisar o uso de providers globais
5. melhorar encoding remanescente em arquivos do repositorio

Prioridade baixa:

6. ampliar exemplos de uso no repositório
7. definir com mais rigor o que e API publica estavel versus detalhe interno

---

## O que preservar

Preservar estas direcoes:

- foco em estabilidade antes de refatoracao ampla
- API publica simples e clara
- root resolution previsivel em contexto instalado
- empacotamento limpo
- release process cada vez mais reproduzivel

---

## O que nao fazer

Evitar especialmente:

- alterar a estrategia de root resolution sem caso real e sem validacao instalada
- reintroduzir arquivos desnecessarios no pacote
- expandir a API publica sem criterio
- misturar redesign grande com melhorias operacionais pequenas

---

## Ordem recomendada para continuar

1. manter `0.2.1.post1` como base estavel
2. na proxima release, usar o fluxo por tag + GitHub Actions em vez de upload manual
3. adicionar smoke test automatizado do pacote instalado
4. revisar excecoes e providers
5. so depois discutir refatoracoes maiores

---

## Resumo curto para retomada futura

1. `infra-core-sdk` esta publicado e validado no PyPI
2. a versao de referencia atual e `0.2.1.post1`
3. o problema original de instalacao/uso foi resolvido
4. README, empacotamento, API publica e root resolution ja foram corrigidos
5. o projeto agora tem workflow de publish, runbook, checklist e decisions versionados
6. o proximo passo operacional mais importante e exercitar uma release real via GitHub Actions por tag
