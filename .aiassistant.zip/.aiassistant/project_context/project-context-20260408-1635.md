---
apply: always
---

# CONTEXTO PERSISTIDO DO PROJETO - infra-core-sdk

## Leitura obrigatoria

Este arquivo registra o snapshot consolidado desta sessao para `infra-core-sdk`.

Ele deve ser usado para retomar o trabalho sem perder:

- o problema real que motivou a fase atual
- as correcoes ja implementadas
- o estado atual da arquitetura
- o que ainda nao foi corrigido

---

## Estado atual do projeto

- projeto: `infra-core-sdk`
- natureza: biblioteca Python distribuivel
- objetivo atual: estabilizar uso via `pip install`

Arquitetura central:

- `core/root`: resolucao de raiz do projeto
- `core/path`: configuracao e operacoes de path
- `credentials`: setup, persistencia e carga de credenciais
- `security`: criptografia Fernet

---

## Problema real desta fase

O pacote funcionava localmente, mas apresentou problemas em outra maquina:

- imports publicos insuficientes
- dificuldade para descobrir a raiz do projeto consumidor quando instalado via `pip`

Diagnostico:

- comportamento local no repositorio nao refletia bem o comportamento instalado em `site-packages`

---

## Correcoes implementadas

### Root resolution

Arquivos:

- `src/infra_core/core/root/root_config.py`
- `src/infra_core/core/root/root_resolver.py`
- `src/infra_core/core/root/exceptions.py`

Correcoes:

- `RootConfig` agora aceita `start_path`
- `RootResolver` tenta `start_path`, depois `cwd`
- quando instalado em `site-packages`, `RootResolver` pode usar fallback baseado no chamador
- foi adicionada `InvalidRootStartPathError`

### API publica

Arquivos:

- `src/infra_core/__init__.py`
- `src/infra_core/core/__init__.py`
- `src/infra_core/core/root/__init__.py`
- `src/infra_core/exceptions/__init__.py`
- `src/infra_core/credentials/exceptions/__init__.py`

Correcoes:

- API publica do pacote foi ampliada e alinhada
- subpacotes antes vazios agora reexportam contratos adequados
- duplicacoes acidentais em `__init__.py` foram removidas

---

## Validacao consolidada

Validado nesta sessao:

- suite local inteira passando
- resultado: `63 passed`
- imports publicos novos funcionando com `PYTHONPATH=src`

Nao validado ainda:

- instalacao da nova versao em outra maquina com o artefato atualizado

---

## Problemas ainda presentes

Problema concreto prioritario:

- `src/infra_core/credentials/services/credentials_service.py` ainda precisa ser corrigido

Problemas de empacotamento:

- o `sdist` inclui arquivos demais
- o pacote ainda precisa ser validado com wheel novo instalado fora do repositorio

Problemas secundarios:

- encoding ruim em README e outros arquivos
- inconsistencias internas de design entre providers globais e uso runtime

---

## Ordem recomendada para continuar

1. gerar nova versao do pacote
2. instalar e validar fora do repositorio
3. corrigir `credentials_service.py`
4. limpar empacotamento
5. so depois discutir melhorias de design

---

## Regra de trabalho para proximas sessoes

- priorizar correcoes que afetam distribuicao e consumo real
- evitar refatoracao ampla antes da validacao do pacote instalado
- considerar a arquitetura atual suficientemente boa para ajustes incrementais, mas ainda nao pronta para redesign grande
